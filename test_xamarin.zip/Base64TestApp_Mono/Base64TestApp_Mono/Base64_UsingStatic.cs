﻿using static System.Convert;

namespace Base64TestApp_Mono
{
    public static class Base64_UsingStatic
    {
        public static string ToBase64(this System.Text.Encoding encoding, string text)
        {
            if (text == null)
            {
                return null;
            }

            byte[] textAsBytes = encoding.GetBytes(text);
            return ToBase64String(textAsBytes);
        }
       
        public static bool TryParseBase64(this System.Text.Encoding encoding, string encodedText, out string decodedText)
        {
            if (encodedText == null)
            {
                decodedText = null;
                return false;
            }

            try
            {
                byte[] textAsBytes = FromBase64String(encodedText);
                decodedText = encoding.GetString(textAsBytes);
                return true;
            }
            catch (System.Exception)
            {
                decodedText = null;
                return false;   
            }
        }
    }
}
