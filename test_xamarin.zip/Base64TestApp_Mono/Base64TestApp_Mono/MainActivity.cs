﻿using Android.App;
using Android.Widget;
using Android.OS;
using System.Text;

namespace Base64TestApp_Mono
{
    [Activity(Label = "Base64TestApp-Mono", MainLauncher = true)]
    public class MainActivity : Activity
    {
        protected override void OnCreate(Bundle savedInstanceState)
        {
            base.OnCreate(savedInstanceState);

            // Set our view from the "main" layout resource
            SetContentView(Resource.Layout.Main);

            var encode1 = Base64.ToBase64(Encoding.UTF8, "");
            string res1;
            var decode1 = Base64.TryParseBase64(Encoding.UTF8, encode1, out res1);
            
            var encode2 = Base64_UsingAlias.ToBase64(Encoding.UTF8, "");
            string res2;
            var decode2 = Base64_UsingAlias.TryParseBase64(Encoding.UTF8, encode2, out res2);
            
            var encode3 = Base64_UsingStatic.ToBase64(Encoding.UTF8, "");
            string res3;
            var decode3 = Base64_UsingStatic.TryParseBase64(Encoding.UTF8, encode3, out res3);
            
            var encode4 = Base64_WithoutUsing.ToBase64(Encoding.UTF8, "");
            string res4;
            var decode4 = Base64_WithoutUsing.TryParseBase64(Encoding.UTF8, encode4, out res4);
        }
    }
}

